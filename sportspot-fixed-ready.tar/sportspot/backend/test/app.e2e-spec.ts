describe('App E2E sanity check', () => {
  it('should run e2e tests successfully', () => {
    expect(true).toBe(true);
  });
});
